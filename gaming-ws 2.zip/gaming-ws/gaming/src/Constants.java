
public interface Constants {
	final int GAME_HEIGHT = 900;
	int GAME_WIDTH = 1200;
	String GAME_TITLE = "Game 2023";
}
