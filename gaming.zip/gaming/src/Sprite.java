import javax.swing.ImageIcon;

public class Sprite implements Constants {
int x;
int y;
int w;
int h;
int speed;
ImageIcon image;


}
