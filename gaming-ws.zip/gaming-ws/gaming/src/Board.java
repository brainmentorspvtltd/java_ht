import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Board extends JPanel {
	BufferedImage image;
	
	public Board() {
		// Load Background Image
		try {
		image = ImageIO.
				read(Board.class.getResource("gameimage.jpeg"));
		}
		catch(Exception e) {
			System.out.println("Problem in Image....");
		}
		}
	
	@Override
	public void paintComponent(Graphics pen) {
		pen.drawImage(image,0,0,1200,900, null);
	}

}








