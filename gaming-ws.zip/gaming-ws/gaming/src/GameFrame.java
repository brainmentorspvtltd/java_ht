import javax.swing.JFrame;

public class GameFrame extends JFrame {
	
	GameFrame(){
		this.setSize(1200,900);
		setTitle("My Game 2023");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new Board());
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
	}

	public static void main(String[] args) {
		GameFrame frame = new GameFrame();
		
		
		//int x = 10;

	}

}
